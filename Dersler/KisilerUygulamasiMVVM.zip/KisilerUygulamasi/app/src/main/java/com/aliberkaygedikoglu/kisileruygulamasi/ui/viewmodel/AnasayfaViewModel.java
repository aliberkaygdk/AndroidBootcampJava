package com.aliberkaygedikoglu.kisileruygulamasi.ui.viewmodel;

import android.util.Log;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.aliberkaygedikoglu.kisileruygulamasi.data.entity.Kisiler;
import com.aliberkaygedikoglu.kisileruygulamasi.data.repo.KisilerDaoRepository;

import java.util.List;

public class AnasayfaViewModel extends ViewModel {

    public KisilerDaoRepository kRepo = new KisilerDaoRepository();
    public MutableLiveData<List<Kisiler>> kisilerListesi;

    public AnasayfaViewModel() {
        kisileriYukle();
        kisilerListesi = kRepo.kisilerListesi;
    }

    public void ara(String aramaKelimesi){

        kRepo.ara(aramaKelimesi);
    }
    public void sil(int kisi_id){
        kRepo.sil(kisi_id);

    }
    public void kisileriYukle(){
        kRepo.kisileriYukle();
    }
}
